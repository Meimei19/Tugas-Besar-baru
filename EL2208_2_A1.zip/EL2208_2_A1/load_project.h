#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void load_project();
char*** csv_to_matrix(char s[30]);
void save(char s[50], char ***A);
